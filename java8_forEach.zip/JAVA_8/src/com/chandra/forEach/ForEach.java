/**
 * 
 */
package com.chandra.forEach;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * @author LGN
 *
 */
public class ForEach {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("<-----------MAP---------->");
		
		Map<String, Integer> mapItems = new HashMap<>();
		mapItems.put("A", 10);
		mapItems.put("B", 20);
		mapItems.put("C", 30);
		mapItems.put("D", 40);
		mapItems.put("E", 50);
		mapItems.put("F", 60);
		System.out.println("###### Normal way to loop a Map");
		for (Map.Entry<String, Integer> entry : mapItems.entrySet()) {
			System.out.println("Item : " + entry.getKey() + " Count : " + entry.getValue());
		}
		System.out.println("###### forEach with lambda way to loop a Map");
		mapItems.forEach((k,v)->System.out.println("Item : " + k + " Count : " + v));

		mapItems.forEach((k,v)->{
			System.out.println("Item : " + k + " Count : " + v);
			if("E".equals(k)){
				System.out.println("Hello E");
			}
		});
		
		System.out.println("<-----------LIST---------->");
		List<String> items = new ArrayList<>();
		items.add("A");
		items.add("B");
		items.add("C");
		items.add("D");
		items.add("E");
		
		System.out.println("###### Normal for-loop to loop a List");
		for(String item : items){
			System.out.println(item);
		}
		
		System.out.println("###### forEach with lambda way to loop a List");
		//lambda
		items.forEach(item->System.out.println(item));

		//get an element
		items.forEach(item->{
			if("C".equals(item)){
				System.out.println(item);
			}
		});

		// using method reference
		items.forEach(System.out::println);

		//UsingStream and filter
		items.stream()
			.filter(s->s.contains("B"))
			.forEach(System.out::println);
	}

}
