/**
 * 
 */
package com.chandra.streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author LGN
 *
 */
public class NewApproach {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        List<String> lines = Arrays.asList("spring", "node", "cluster");

        System.out.println("1. Streams filter() and collect()");
        
        List<String> result = lines.stream()                // convert list to stream
                .filter(line -> !"cluster".equals(line))    
                .collect(Collectors.toList());              // collect the output and convert streams to a List

        result.forEach(System.out::println);                //output : spring, node

        System.out.println("2. Streams filter(), findAny() and orElse()");
        
        List<Person> persons = Arrays.asList(
                new Person("cluster", 30),
                new Person("jack", 20),
                new Person("lawrence", 40)
        );

        Person result1 = persons.stream()                        // Convert to steam
                .filter(x -> "jack".equals(x.getName()))        // we want "jack" only
                .findAny()                                      // If 'findAny' then return found
                .orElse(null);                                  // If not found, return null

        System.out.println(result1);

        Person result2 = persons.stream()
                .filter(x -> "ahmook".equals(x.getName()))
                .findAny()
                .orElse(null);

        System.out.println(result2);
        
        System.out.println("3. Streams filter() and map()");
        
        Person result3 = persons.stream()
                .filter((p) -> "jack".equals(p.getName()) && 20 == p.getAge())
                .findAny()
                .orElse(null);

        System.out.println("result 1 :" + result3);

        //or like this
        Person result4 = persons.stream()
                .filter(p -> {
                    if ("jack".equals(p.getName()) && 20 == p.getAge()) {
                        return true;
                    }
                    return false;
                }).findAny()
                .orElse(null);

        System.out.println("result 2 :" + result4);

	}

}
