/**
 * 
 */
package com.chandra.streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author LGN
 *
 */
public class ExistingApproach {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

        List<String> lines = Arrays.asList("spring", "node", "cluster");
        List<String> result = getFilterOutput(lines, "cluster");
        for (String temp : result) {
            System.out.println(temp);    //output : spring, node
        }
        
        
        List<Person> persons = Arrays.asList(
                new Person("mkyong", 30),
                new Person("jack", 20),
                new Person("lawrence", 40)
        );

        Person result1 = getStudentByName(persons, "jack");
        System.out.println(result1);


    }

    private static List<String> getFilterOutput(List<String> lines, String filter) {
        List<String> result = new ArrayList<>();
        for (String line : lines) {
            if (!"cluster".equals(line)) { 
                result.add(line);
            }
        }
        return result;
    }
    
    private static Person getStudentByName(List<Person> persons, String name) {

        Person result = null;
        for (Person temp : persons) {
            if (name.equals(temp.getName())) {
                result = temp;
            }
        }
        return result;
    }

}
